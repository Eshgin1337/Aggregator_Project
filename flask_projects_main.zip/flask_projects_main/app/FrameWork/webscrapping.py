class WebScrapping():

    def __init__(self, minimum_product_value, maximum_product_value, cargo_cost, prizes_in_tapaz, prizes_in_amazon, prizes_in_aliexpress, value_inter_to_search, descending_or_acending, aliexpress_products, amazon_products, tapaz_products, currency_of_prize):
        
        self.prizes_in_tapaz = prizes_in_tapaz
        
        self.minimum_product_value = minimum_product_value
        
        self.maximum_product_value = maximum_product_value
        
        self.aliexpress_products = aliexpress_products
        
        self.prizes_in_amazon = prizes_in_amazon
        
        self.cargo_cost = cargo_cost
        
        self.currency_of_prize = currency_of_prize
        
        
        self.descending_or_acending = descending_or_acending
        
        self.prizes_in_aliexpress = prizes_in_aliexpress
        
        self.value_inter_to_search = value_inter_to_search
        
        self.tapaz_products = tapaz_products
        
        self.amazon_products = amazon_products

    def get_min_value(self):
        return self.minimum_product_value


    def get_max_value(self):
        return self.maximum_product_value


    def get_cargo(self):
        return self.cargo_cost


    def get_val_in_tapaz(self):
        return self.prizes_in_tapaz


    def get_val_in_amazon(self):

        return self.prizes_in_amazon


    def get_val_in_aliexpress(self):
        return self.prizes_in_aliexpress


    def get_val_to_search(self):
        return self.value_inter_to_search


    def get_descending_or_acending(self):
        return self.descending_or_acending


    def get_products_aliexpress(self):
        return self.aliexpress_products


    def get_products_amazon(self):
        return self.amazon_products


    def get_products_tapaz(self):
        return self.tapaz_products


    def get_prize_currency(self):
        return self.currency_of_prize

