from selenium import*
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from random import*
import os
from time import sleep
from selenium.webdriver.chrome.options import*

browser = webdriver.Chrome()

class Webscraper():
    def __init__(self):
        pass

    def search_products(self):
        pass
