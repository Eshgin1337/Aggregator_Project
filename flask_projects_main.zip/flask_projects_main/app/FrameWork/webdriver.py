from .webengine import*

class Aliexpress_Scrapper(Webscraper):
    def __init__(self):
        driver.get('https://best.aliexpress.com/?lan=en')

    def search_products(self, search_product):


        try:
            driver.find_element_by_tag_name('dt[class="cate-name"]').click()
            sleep(0.5)
        except:
            None
        search = driver.find_element_by_tag_name('input[id="search-key"]')
        search.clear()
        search.send_keys(search_product)
        driver.find_element_by_tag_name(
            'input[class="search-button"]').click()
        item_list = []
        sleep(2)


        i = 0

        s = 700

        loop = 8
        while i < 20:
            try:
                item = driver.find_element_by_tag_name(
                    'div[item-index="{}"]'.format(i))
                product_picture = item.find_element_by_tag_name(
                    'img[class="item-img"]')
                link_to_product = item.find_element_by_tag_name(
                    'a[target="_blank"]')
                product_description = item.find_element_by_tag_name(
                    'a[class="item-title"]')
                try:
                    price = item.find_element_by_tag_name(
                        'span[class="price-current"]')
                    if price.text[5] == '.':
                        integer_form_prize = price.text[4:5]
                    if price.text[6] == '.':
                        integer_form_prize = price.text[4:6]
                    if price.text[7] == '.':
                        integer_form_prize = price.text[4:7]
                    try:
                        shipping = item.find_element_by_tag_name(
                            'span[class="shipping-value"]')
                        item_list.append([product_picture.get_attribute('src'), product_description.text, link_to_product.get_attribute(
                            'href'), price.text, int(integer_form_prize), shipping.text])
                    except:
                        item_list.append([product_picture.get_attribute('src'), product_description.text, link_to_product.get_attribute(
                            'href'), price.text, int(integer_form_prize), -1])
                    i += 1
                except:
                    try:
                        shipping = item.find_element_by_tag_name(
                            'span[class="shipping-value"]')
                        item_list.append([product_picture.get_attribute(
                            'src'), product_description.text, link_to_product.get_attribute('href'), -1, -1, shipping.text])
                    except:
                        item_list.append([product_picture.get_attribute(
                            'src'), product_description.text, link_to_product.get_attribute('href'), -1, -1, -1])
                    i += 1
                    continue
            except:
                if i == loop:
                    driver.execute_script('window.scrollTo(0,{})'.format(s))
                    sleep(1)
                i += 1
                continue
        return item_list

aliexpress_scrapper = Aliexpress_Scrapper()


class Amazon_Scrapper(Webscraper):

    def __init__(self):
        driver.get("https://www.amazon.com")

    def search_products(self, search_product):
        search = driver.find_element_by_id("twotabsearchtextbox")
        search.clear()
        search.send_keys(search_product)
        search.send_keys(Keys.RETURN)
        sleep(2)
        item_list = []
        i = 1
        while i < 20:
            try:
                item = driver.find_element_by_tag_name(
                    'div[data-index="{}"]'.format(i))
                product_picture = driver.find_element_by_tag_name(
                    'img[data-image-index="{}"]'.format(i))
                link_to_product = item.find_element_by_tag_name(
                    'a[class="a-link-normal a-text-normal"]')
                product_description = item.find_element_by_tag_name(
                    'span[class="a-size-medium a-color-base a-text-normal"]')
                try:
                    price = item.find_element_by_tag_name(
                        'span[class="a-price"]')
                    integer_form_prize = item.find_element_by_tag_name(
                        'span[class="a-price-whole"]')
                    item_list.append([product_picture.get_attribute('src'), product_description.text, link_to_product.get_attribute(
                        'href'), str(price.text), int(integer_form_prize.text), -1])
                    i += 1
                except:
                    item_list.append([product_picture.get_attribute(
                        'src'), product_description.text, link_to_product.get_attribute('href'), -1, -1, -1])
                    i += 1
                    continue
            except:
                i += 1
                continue
        return item_list

amazon_scrapper = Amazon_Scrapper()


class Tapaz_Scrapper(Webscraper):
    def __init__(self):
        driver.get('https://tap.az')

    def search_products(self, search_product):
        search = driver.find_element_by_tag_name('input[id="keywords"]')
        search.clear()
        search.send_keys(search_product)
        search.send_keys(Keys.RETURN)
        sleep(2)
        item_list = []

        i = 0
        s = 200

        driver.execute_script('window.scrollTo(0,5000)')
        sleep(0.5)
        products = driver.find_elements_by_tag_name(
            'div[class="products-i rounded "')
        for product in products:
            if i < 20:
                link_to_product = product.find_element_by_tag_name(
                    'a[class="products-link"]')
                product_description = product.find_element_by_tag_name(
                    'div[class="products-name"]')
                try:
                    price = product.find_element_by_tag_name(
                        'div[class="products-price"]')
                    integer_form_prize = product.find_element_by_tag_name(
                        'span[class="price-val"]')
                    item_list.append(
                        [-1, product_description.text, link_to_product.get_attribute('href'), price.text, int(integer_form_prize.text), -1])
                    i += 1
                except:
                    item_list.append(
                        [-1, product_description.text, link_to_product.get_attribute('href'), -1, -1, -1])
                    i += 1
                    continue
        return item_list

tapaz_scrapper = Tapaz_Scrapper()