class Sort:
    def __init__(self, item_list, currency_of_prize, order):
        self.item_list = item_list
        self.currency_of_prize = currency_of_prize
        self.order = order

    def sort_items(self):

        curr = []
        if self.currency_of_prize == 'Dollar':

            for i in self.item_list:
                curr = list(str(i[3]))
                curr = curr[0:2]
                if curr[0] != "$":
                    break
                curr[0] = '$ '
                i[4] = i[4] / 1.71
                curr[1] = str(round(i[4], 2))
                i[3] = ''

                for k in curr:
                    i[3] += k
        if self.currency_of_prize == 'Manat':

            for i in self.item_list:
                curr = list(str(i[3]))
                curr = curr[0:2]
                if curr[0] != "$":
                    break
                curr[0] = 'AZN'
                i[4] = i[4] * 1.71
                curr[1] = str(round(i[4], 2))
                i[3] = ''

                for k in curr:
                    i[3] += k


        if self.order == "Descending":
            self.item_list.sort(key=lambda curr: curr[4])


        if self.order == "Ascending":
            self.item_list.sort(key=lambda curr: curr[4])
        
            self.item_list.reverse()
        return self.item_list
